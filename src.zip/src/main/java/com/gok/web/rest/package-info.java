/**
 * Spring MVC REST controllers.
 */
package com.gok.web.rest;
