/**
 * View Models used by Spring MVC REST controllers.
 */
package com.gok.web.rest.vm;
