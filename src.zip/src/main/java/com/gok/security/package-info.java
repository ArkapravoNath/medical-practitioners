/**
 * Spring Security configuration.
 */
package com.gok.security;
