/**
 * Spring Data JPA repositories.
 */
package com.gok.repository;
