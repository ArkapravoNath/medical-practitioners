/**
 * JPA domain objects.
 */
package com.gok.domain;
