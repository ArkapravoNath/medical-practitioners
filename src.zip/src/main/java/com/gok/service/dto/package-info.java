/**
 * Data Transfer Objects.
 */
package com.gok.service.dto;
