/**
 * Service layer beans.
 */
package com.gok.service;
